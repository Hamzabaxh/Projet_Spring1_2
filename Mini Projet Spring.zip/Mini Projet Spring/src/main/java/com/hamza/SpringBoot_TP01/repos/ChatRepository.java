package com.hamza.SpringBoot_TP01.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamza.SpringBoot_TP01.entities.Chat;

public interface ChatRepository extends JpaRepository<Chat, Long> {
	

}
