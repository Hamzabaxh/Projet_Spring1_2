package com.hamza.SpringBoot_TP01.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.hamza.SpringBoot_TP01.entities.Chat;
import com.hamza.SpringBoot_TP01.repos.ChatRepository;

@Service
public class ChatServiceImpl implements ChatService {
	
	@Autowired
	private ChatRepository chatRepo;

	@Override
	public Chat saveChat(Chat c) {
		return this.chatRepo.save(c);
	}

	@Override
	public Chat updateChat(Chat c) {
		return this.chatRepo.save(c);
	}

	@Override
	public void deleteChat(Chat c) {
		this.chatRepo.delete(c);
		
	}

	@Override
	public void deleteChatById(Long id) {
		this.chatRepo.deleteById(id);
		
	}

	@Override
	public Chat getChat(Long id) {
		return this.chatRepo.findById(id).orElse(null);
	}

	@Override
	public List<Chat> getAllChats() {
		return this.chatRepo.findAll();
	}

	@Override
	public Page<Chat> getAllChatsByPage(int page, int size) {
		return this.chatRepo.findAll(PageRequest.of(page, size));
	}
}
