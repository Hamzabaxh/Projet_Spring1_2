package com.hamza.SpringBoot_TP01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTp01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTp01Application.class, args);
	}

}
