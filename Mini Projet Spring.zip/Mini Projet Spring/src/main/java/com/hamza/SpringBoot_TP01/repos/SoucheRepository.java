package com.hamza.SpringBoot_TP01.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.hamza.SpringBoot_TP01.entities.Souche;

public interface SoucheRepository extends JpaRepository<Souche, Long> {

}
