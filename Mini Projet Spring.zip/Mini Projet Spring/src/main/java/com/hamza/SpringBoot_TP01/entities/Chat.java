package com.hamza.SpringBoot_TP01.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Chat {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long idChat;
	private String nomChat;
	private double prixAdoption;
	private Date dateNaissance;
	
	@ManyToOne
	private Souche souche;

	public Chat() {
		super();
	}
	
	public Chat(String nomChat, double prixAdoption, Date dateNaissance, Souche souche) {
		super();
		this.nomChat = nomChat;
		this.prixAdoption = prixAdoption;
		this.dateNaissance = dateNaissance;
		this.souche = souche;
	}

	public long getIdChat() {
		return idChat;
	}

	public void setIdChat(long idChat) {
		this.idChat = idChat;
	}

	public String getNomChat() {
		return nomChat;
	}

	public void setNomChat(String nomChat) {
		this.nomChat = nomChat;
	}

	public double getPrixAdoption() {
		return prixAdoption;
	}

	public void setPrixAdoption(double prixAdoption) {
		this.prixAdoption = prixAdoption;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	
	public Souche getSouche() {
		return souche;
	}

	public void setSouche(Souche souche) {
		this.souche = souche;
	}

	@Override
	public String toString() {
		return "Chat [idChat=" + idChat + ", nomChat=" + nomChat + ", prixAdoption=" + prixAdoption + ", dateNaissance="
				+ dateNaissance + ", souche=" + souche + "]";
	}
}
