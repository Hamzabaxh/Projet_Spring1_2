package com.hamza.SpringBoot_TP01.services;

import java.util.List;

import com.hamza.SpringBoot_TP01.entities.Chat;
import com.hamza.SpringBoot_TP01.entities.Souche;

public interface SoucheService {
    
    public void addSouche(Souche souche);
    
    public List<Souche> getAllSouches();
    
    public Souche getSoucheById(Long id);
    
    public void deleteSoucheById(Long id);
    
    public void addChatToSouche(Souche souche, Chat chat);

}
