package com.hamza.SpringBoot_TP01.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hamza.SpringBoot_TP01.entities.Chat;
import com.hamza.SpringBoot_TP01.entities.Souche;
import com.hamza.SpringBoot_TP01.repos.SoucheRepository;

@Service
public class SoucheServiceImpl implements SoucheService {

	@Autowired
	private SoucheRepository soucheRepo;

	@Override
	public void addSouche(Souche souche) {
		this.soucheRepo.save(souche);
	}

	@Override
	public List<Souche> getAllSouches() {
		return this.soucheRepo.findAll();
	}

	@Override
	public Souche getSoucheById(Long id) {
		return this.soucheRepo.findById(id).orElse(null);
	}

	@Override
	public void deleteSoucheById(Long id) {
		this.soucheRepo.deleteById(id);
	}

	@Override
	public void addChatToSouche(Souche souche, Chat chat) {
		List<Chat> chats = souche.getChats();
		chats.add(chat);
		souche.setChats(chats);
		this.soucheRepo.save(souche);
	}

}
