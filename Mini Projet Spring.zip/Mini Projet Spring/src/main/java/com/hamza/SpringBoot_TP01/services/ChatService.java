package com.hamza.SpringBoot_TP01.services;

import java.util.List;

import org.springframework.data.domain.Page;

import com.hamza.SpringBoot_TP01.entities.Chat;

public interface ChatService {
	Chat saveChat(Chat c);
	
	Chat updateChat(Chat c);
	
	void deleteChat(Chat c);
	
	void deleteChatById(Long id);
	
	Chat getChat(Long id);
	
	List<Chat> getAllChats();
	
	Page<Chat> getAllChatsByPage(int page, int size);

}
