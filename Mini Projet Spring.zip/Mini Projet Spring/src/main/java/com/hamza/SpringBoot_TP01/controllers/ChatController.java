 package com.hamza.SpringBoot_TP01.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hamza.SpringBoot_TP01.entities.Chat;
import com.hamza.SpringBoot_TP01.services.ChatService;
import com.hamza.SpringBoot_TP01.services.SoucheService;

@Controller
public class ChatController {

    @Autowired
    private ChatService chatService;
    
    @Autowired
    private SoucheService soucheService;

    @GetMapping("/create")
    public String createChatPage(ModelMap modelMap) {
    	
    	modelMap.addAttribute("souches", this.soucheService.getAllSouches());
        return "createChat";
    }

    @PostMapping("/saveChat")
    public String saveChat(@ModelAttribute("chat") Chat chat, @RequestParam("date") String date, ModelMap modelMap) throws ParseException {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dateCreation = dateFormat.parse(date);
        chat.setDateNaissance(dateCreation);

        Chat savedChat = this.chatService.saveChat(chat);
        String msg = "Chat avec ID : " + savedChat.getIdChat() + " et du nom : " + savedChat.getNomChat() +  " enregistré avec succès";
        modelMap.addAttribute("msg", msg);

        Page<Chat> chats = this.chatService.getAllChatsByPage(0, 2);
        modelMap.addAttribute("chats", chats);
        modelMap.addAttribute("pages", new int[chats.getTotalPages()]);
        modelMap.addAttribute("currentPage", chats.getTotalPages() - 1);

        return "listerChats";
    }

    @GetMapping("/lister")
    public String listerChats(ModelMap modelMap, @RequestParam(name="page", defaultValue="0") int page, @RequestParam(name="size", defaultValue="2") int size) {

        Page<Chat> chats = this.chatService.getAllChatsByPage(page, size);
        modelMap.addAttribute("chats", chats);
        modelMap.addAttribute("pages", new int[chats.getTotalPages()]);
        modelMap.addAttribute("currentPage", page);

        return "listerChats";
    }

    @GetMapping("/editerChat")
    public String editerChatPage(@RequestParam("id") Long id, ModelMap modelMap) {
        Chat chat = this.chatService.getChat(id);

        Date dateCreation = chat.getDateNaissance();
        LocalDateTime localDateTimeCreation = dateCreation.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

        modelMap.addAttribute("dateCreation", localDateTimeCreation);
        modelMap.addAttribute("chat", chat);

        return "editerChat";
    }

    @PostMapping("/editerChat")
    public String editerChat(@ModelAttribute("chat") Chat chat, @RequestParam("date") String date, @RequestParam(name="page", defaultValue="0") int page, @RequestParam(name="size", defaultValue="2") int size, ModelMap modelMap) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dateNaissance = dateFormat.parse(date);
        chat.setDateNaissance(dateNaissance);

        this.chatService.updateChat(chat);

        Page<Chat> chats = this.chatService.getAllChatsByPage(page, size);
        modelMap.addAttribute("chats", chats);
        modelMap.addAttribute("pages", new int[chats.getTotalPages()]);
        modelMap.addAttribute("currentPage", page);

        return "listerChats";
    }

	@GetMapping("/supprimerChat")
	public String supprimerChat(@RequestParam("id") Long id, ModelMap modelMap, @RequestParam(name="page", defaultValue="0") int page, @RequestParam(name="size", defaultValue="2") int size) {
		System.out.println(page);
		Page<Chat> chat1 = this.chatService.getAllChatsByPage(page, size);
		System.out.println(chat1.getTotalPages());


		this.chatService.deleteChatById(id);
		
		Page<Chat> chats = this.chatService.getAllChatsByPage(page, size);
		
		System.out.println(chats.getTotalPages());

		
		modelMap.addAttribute("chats", chats);
		modelMap.addAttribute("pages", new int[chats.getTotalPages()]);
		
		modelMap.addAttribute("currentPage", page);
		
		return "listerChats";
	}
}
