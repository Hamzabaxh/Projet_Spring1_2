package com.hamza.SpringBoot_TP01;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;

import com.hamza.SpringBoot_TP01.entities.Chat;
import com.hamza.SpringBoot_TP01.entities.Souche;
import com.hamza.SpringBoot_TP01.repos.ChatRepository;
import com.hamza.SpringBoot_TP01.services.ChatService;
import com.hamza.SpringBoot_TP01.services.SoucheService;

@SpringBootTest
class SpringBootTp01ApplicationTests {

	@Autowired
	private ChatRepository chatRepo;
	
	@Autowired
	private SoucheService soucheService;
	
	@Autowired
	private ChatService chatService;
	
	@Test
	public void testCreateChat() {
		
		Souche souche = new Souche("Chat Persan");
		Chat chat = new Chat("Sousou", 6660.0, new Date(), souche);
		chat.setSouche(souche);
		souche.getChats().add(chat);
		

		this.chatRepo.save(chat);
	}
	
	@Test
	public Chat testFindChatByID(long id) {
		Chat chat = this.chatRepo.findById(id).get();
		
		System.out.println("Debut De La Fonction ' findChatByID(id)' ");
		
		System.out.println(
				"Chat Id : " + chat.getIdChat() + 
				" \nLe Nom De Chat : " + chat.getNomChat() + 
				" \nLe Prix D'adoption : " + chat.getPrixAdoption() + " DT" +  
				" \nLa Date De Naissance : " + chat.getDateNaissance()
		);
		
		System.out.println("Fin La Fonction ' findChatByID(id)' ");

		
		return chat;
	}
	
	@Test
	public void testUpdateChat() {
		Chat chat = this.testFindChatByID(1L);
		
		System.out.println("Debut La Fonction ' updateChat()' ");

		
		chat.setPrixAdoption(1500.0);
		
		this.chatRepo.save(chat);
		
		System.out.println("\n Chat Apres La Modification \n");
		
		System.out.println(
				"Chat Id : " + chat.getIdChat() + 
				" \nLe Nom De Chat : " + chat.getNomChat() + 
				" \nLe Prix D'adoption : " + chat.getPrixAdoption() + " DT" +  
				" \nLa Date De Naissance : " + chat.getDateNaissance()
		);
		
		System.out.println("Fin La Fonction ' updateChat()' ");
	}
	
	@Test
	public void testDeleteChat() {
		Chat chat = this.chatRepo.findById(1L).get();
		this.chatRepo.delete(chat);
	}
	
	@Test
	public void testGetAllChats() {
		List<Chat> chats = this.chatRepo.findAll();
		
		for(Chat chat : chats) {
			System.out.println(chat);
		}
	}
	
	@Test
	public void testFindByNomChatContains() {
		Page<Chat> chats = this.chatService.getAllChatsByPage(0, 2);
		System.out.println(chats.getSize());
		System.out.println(chats.getTotalElements());
		System.out.println(chats.getTotalPages());
		
		chats.getContent().forEach(chat -> {
			System.out.println(chat);
		});
	}
}
